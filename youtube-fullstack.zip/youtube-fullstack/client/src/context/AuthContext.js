// client/src/context/AuthContext.js
import React, { createContext, useContext, useState, useEffect } from "react";
import api from "../api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("yt_token");
    if (token) {
      api.get("/auth/me")
        .then(r => setUser(r.data))
        .catch(() => localStorage.removeItem("yt_token"))
        .finally(() => setLoading(false));
    } else setLoading(false);
  }, []);

  const login = async (email, password) => {
    const { data } = await api.post("/auth/login", { email, password });
    localStorage.setItem("yt_token", data.token);
    setUser(data.user);
    return data;
  };

  const register = async (username, email, password, channelName) => {
    const { data } = await api.post("/auth/register", { username, email, password, channelName });
    localStorage.setItem("yt_token", data.token);
    setUser(data.user);
    return data;
  };

  const logout = () => { localStorage.removeItem("yt_token"); setUser(null); };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
