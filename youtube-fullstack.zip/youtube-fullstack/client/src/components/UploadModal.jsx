// client/src/components/UploadModal.jsx
import React, { useState, useRef } from "react";
import { videosAPI } from "../api";

const CATEGORIES = ["Music", "Gaming", "Education", "Comedy", "News", "Sports", "Technology", "Cooking", "Travel", "Film", "Science", "General"];

export default function UploadModal({ onClose, onSuccess }) {
  const [step, setStep] = useState("drop"); // drop | details | uploading | done
  const [videoFile, setVideoFile] = useState(null);
  const [thumbFile, setThumbFile] = useState(null);
  const [dragging, setDragging] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ title: "", description: "", category: "General", visibility: "public", tags: "" });
  const videoRef = useRef(null);
  const thumbRef = useRef(null);

  const handleFile = (file) => {
    if (!file || !file.type.startsWith("video/")) { setError("Please select a valid video file."); return; }
    setVideoFile(file);
    setForm(f => ({ ...f, title: file.name.replace(/\.[^/.]+$/, "") }));
    setStep("details");
    setError("");
  };

  const handleDrop = (e) => { e.preventDefault(); setDragging(false); handleFile(e.dataTransfer.files[0]); };

  const submit = async () => {
    if (!form.title.trim()) { setError("Title is required"); return; }
    setStep("uploading");
    setProgress(0);
    try {
      const fd = new FormData();
      fd.append("video", videoFile);
      fd.append("title", form.title);
      fd.append("description", form.description);
      fd.append("category", form.category);
      fd.append("visibility", form.visibility);
      fd.append("tags", JSON.stringify(form.tags.split(",").map(t => t.trim()).filter(Boolean)));
      const { data: video } = await videosAPI.upload(fd, setProgress);
      if (thumbFile) {
        const tf = new FormData(); tf.append("thumbnail", thumbFile);
        await videosAPI.uploadThumbnail(video.id, tf);
      }
      setStep("done");
      onSuccess?.(video);
    } catch (e) { setError(e.response?.data?.error || "Upload failed"); setStep("details"); }
  };

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.85)", zIndex:9999, display:"flex", alignItems:"center", justifyContent:"center" }}>
      <div style={{ background:"#0f0f0f", border:"1px solid #2a2a2a", borderRadius:14, width:640, maxWidth:"96vw", maxHeight:"92vh", overflowY:"auto" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"18px 24px", borderBottom:"1px solid #1e1e1e" }}>
          <h2 style={{ fontSize:18, fontWeight:700, color:"#f1f5f9", margin:0 }}>Upload video</h2>
          <button onClick={onClose} style={{ background:"none", border:"none", color:"#aaa", fontSize:22, cursor:"pointer", lineHeight:1 }}>✕</button>
        </div>

        <div style={{ padding:24 }}>
          {error && <div style={{ background:"#2a0e0e", border:"1px solid #ef4444", borderRadius:8, padding:"10px 14px", color:"#fca5a5", fontSize:13, marginBottom:16 }}>{error}</div>}

          {step === "drop" && (
            <div onDragOver={e => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={handleDrop}
              style={{ border:`2px dashed ${dragging ? "#ff0000" : "#333"}`, borderRadius:12, padding:"64px 24px", textAlign:"center", background: dragging ? "rgba(255,0,0,0.03)" : "#0a0a0a", transition:"all 0.2s" }}>
              <div style={{ fontSize:56, marginBottom:16 }}>🎬</div>
              <p style={{ fontSize:16, fontWeight:600, color:"#e2e8f0", marginBottom:8 }}>Drag and drop video files to upload</p>
              <p style={{ fontSize:13, color:"#64748b", marginBottom:24 }}>Your videos will be private until you publish them</p>
              <button onClick={() => videoRef.current?.click()} style={{ background:"#3ea6ff", color:"#0f0f0f", border:"none", padding:"11px 28px", borderRadius:22, fontSize:14, fontWeight:700, cursor:"pointer" }}>SELECT FILES</button>
              <input ref={videoRef} type="file" accept="video/*" style={{ display:"none" }} onChange={e => handleFile(e.target.files[0])} />
            </div>
          )}

          {step === "details" && (
            <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
              <div>
                <label style={{ fontSize:12, color:"#94a3b8", display:"block", marginBottom:6 }}>Title <span style={{color:"#ef4444"}}>*</span></label>
                <input value={form.title} onChange={e => setForm(f => ({...f, title: e.target.value}))} style={{ width:"100%", background:"#1a1a1a", border:"1px solid #2a2a2a", borderRadius:6, padding:"10px 12px", color:"#e2e8f0", fontSize:14, outline:"none", boxSizing:"border-box" }} />
              </div>
              <div>
                <label style={{ fontSize:12, color:"#94a3b8", display:"block", marginBottom:6 }}>Description</label>
                <textarea value={form.description} onChange={e => setForm(f => ({...f, description: e.target.value}))} rows={4} placeholder="Tell viewers about your video..." style={{ width:"100%", background:"#1a1a1a", border:"1px solid #2a2a2a", borderRadius:6, padding:"10px 12px", color:"#e2e8f0", fontSize:14, outline:"none", resize:"vertical", boxSizing:"border-box" }} />
              </div>
              <div style={{ display:"flex", gap:12 }}>
                <div style={{ flex:1 }}>
                  <label style={{ fontSize:12, color:"#94a3b8", display:"block", marginBottom:6 }}>Category</label>
                  <select value={form.category} onChange={e => setForm(f => ({...f, category: e.target.value}))} style={{ width:"100%", background:"#1a1a1a", border:"1px solid #2a2a2a", borderRadius:6, padding:"10px 12px", color:"#e2e8f0", fontSize:14, outline:"none" }}>
                    {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div style={{ flex:1 }}>
                  <label style={{ fontSize:12, color:"#94a3b8", display:"block", marginBottom:6 }}>Visibility</label>
                  <select value={form.visibility} onChange={e => setForm(f => ({...f, visibility: e.target.value}))} style={{ width:"100%", background:"#1a1a1a", border:"1px solid #2a2a2a", borderRadius:6, padding:"10px 12px", color:"#e2e8f0", fontSize:14, outline:"none" }}>
                    <option value="public">Public</option>
                    <option value="unlisted">Unlisted</option>
                    <option value="private">Private</option>
                  </select>
                </div>
              </div>
              <div>
                <label style={{ fontSize:12, color:"#94a3b8", display:"block", marginBottom:6 }}>Tags (comma-separated)</label>
                <input value={form.tags} onChange={e => setForm(f => ({...f, tags: e.target.value}))} placeholder="music, tutorial, vlog" style={{ width:"100%", background:"#1a1a1a", border:"1px solid #2a2a2a", borderRadius:6, padding:"10px 12px", color:"#e2e8f0", fontSize:14, outline:"none", boxSizing:"border-box" }} />
              </div>
              <div>
                <label style={{ fontSize:12, color:"#94a3b8", display:"block", marginBottom:8 }}>Thumbnail (optional)</label>
                <button onClick={() => thumbRef.current?.click()} style={{ background:"#1a1a1a", border:"1px dashed #2a2a2a", borderRadius:8, padding:"10px 16px", color:"#94a3b8", fontSize:13, cursor:"pointer", width:"100%" }}>
                  {thumbFile ? `✅ ${thumbFile.name}` : "📷 Upload thumbnail image"}
                </button>
                <input ref={thumbRef} type="file" accept="image/*" style={{ display:"none" }} onChange={e => setThumbFile(e.target.files[0])} />
              </div>
              <div style={{ display:"flex", justifyContent:"flex-end", gap:10, marginTop:8 }}>
                <button onClick={() => { setStep("drop"); setVideoFile(null); }} style={{ background:"none", border:"1px solid #2a2a2a", color:"#94a3b8", padding:"9px 20px", borderRadius:6, cursor:"pointer", fontSize:13 }}>Back</button>
                <button onClick={submit} style={{ background:"#ff0000", color:"#fff", border:"none", padding:"9px 24px", borderRadius:6, cursor:"pointer", fontSize:13, fontWeight:700 }}>Upload & Publish</button>
              </div>
            </div>
          )}

          {step === "uploading" && (
            <div style={{ textAlign:"center", padding:"40px 20px" }}>
              <div style={{ fontSize:48, marginBottom:16 }}>⏳</div>
              <p style={{ fontSize:16, fontWeight:600, color:"#e2e8f0", marginBottom:12 }}>Uploading… {progress}%</p>
              <div style={{ background:"#1a1a1a", borderRadius:20, height:6, overflow:"hidden" }}>
                <div style={{ height:"100%", width:`${progress}%`, background:"linear-gradient(90deg,#ff0000,#ff6b6b)", transition:"width 0.2s", borderRadius:20 }} />
              </div>
              <p style={{ fontSize:12, color:"#64748b", marginTop:12 }}>Do not close this window</p>
            </div>
          )}

          {step === "done" && (
            <div style={{ textAlign:"center", padding:"40px 20px" }}>
              <div style={{ fontSize:56, marginBottom:16 }}>✅</div>
              <p style={{ fontSize:18, fontWeight:700, color:"#e2e8f0", marginBottom:8 }}>Video uploaded successfully!</p>
              <p style={{ fontSize:13, color:"#64748b", marginBottom:24 }}>Your video is being processed and will be available shortly.</p>
              <button onClick={onClose} style={{ background:"#ff0000", color:"#fff", border:"none", padding:"11px 32px", borderRadius:6, cursor:"pointer", fontSize:14, fontWeight:700 }}>Done</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
