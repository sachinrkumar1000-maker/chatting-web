// client/src/api.js — Axios API client
import axios from "axios";

const api = axios.create({ baseURL: "http://localhost:5000/api" });

api.interceptors.request.use(config => {
  const token = localStorage.getItem("yt_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  res => res,
  err => { if (err.response?.status === 401) localStorage.removeItem("yt_token"); return Promise.reject(err); }
);

export default api;

// ── API helpers ──────────────────────────────────────────────
export const videosAPI = {
  getAll: (params) => api.get("/videos", { params }),
  getById: (id) => api.get(`/videos/${id}`),
  upload: (formData, onProgress) => api.post("/videos", formData, { onUploadProgress: e => onProgress?.(Math.round(e.loaded * 100 / e.total)) }),
  update: (id, data) => api.put(`/videos/${id}`, data),
  delete: (id) => api.delete(`/videos/${id}`),
  uploadThumbnail: (id, formData) => api.post(`/videos/${id}/thumbnail`, formData),
  like: (id, type) => api.post(`/videos/${id}/like`, { type }),
  getComments: (id) => api.get(`/videos/${id}/comments`),
  addComment: (id, text, parentId) => api.post(`/videos/${id}/comments`, { text, parentId }),
  deleteComment: (id) => api.delete(`/comments/${id}`),
};

export const channelsAPI = {
  get: (id) => api.get(`/channels/${id}`),
  subscribe: (id) => api.post(`/channels/${id}/subscribe`),
};

export const subscriptionsAPI = {
  getFeed: () => api.get("/subscriptions"),
};

export const playlistsAPI = {
  create: (data) => api.post("/playlists", data),
  get: (id) => api.get(`/playlists/${id}`),
  addVideo: (playlistId, videoId) => api.post(`/playlists/${playlistId}/videos`, { videoId }),
};
