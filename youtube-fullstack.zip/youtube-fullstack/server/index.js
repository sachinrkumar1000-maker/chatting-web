// ============================================================
//  server/index.js  —  YouTube Clone Backend
//  Stack: Node.js · Express · SQLite (dev) · Multer (uploads)
// ============================================================
const express = require("express");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production";

app.use(cors({ origin: "http://localhost:3000", credentials: true }));
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

const db = new Database("youtube.db");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    avatar_url TEXT,
    channel_name TEXT,
    subscriber_count INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS videos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    video_url TEXT NOT NULL,
    thumbnail_url TEXT,
    duration INTEGER DEFAULT 0,
    view_count INTEGER DEFAULT 0,
    like_count INTEGER DEFAULT 0,
    dislike_count INTEGER DEFAULT 0,
    comment_count INTEGER DEFAULT 0,
    tags TEXT DEFAULT '[]',
    category TEXT DEFAULT 'General',
    visibility TEXT DEFAULT 'public',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    video_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    parent_id INTEGER,
    text TEXT NOT NULL,
    like_count INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (video_id) REFERENCES videos(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subscriber_id INTEGER NOT NULL,
    channel_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(subscriber_id, channel_id),
    FOREIGN KEY (subscriber_id) REFERENCES users(id),
    FOREIGN KEY (channel_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS likes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    video_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, video_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (video_id) REFERENCES videos(id)
  );
  CREATE TABLE IF NOT EXISTS watch_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    video_id INTEGER NOT NULL,
    watched_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (video_id) REFERENCES videos(id)
  );
  CREATE TABLE IF NOT EXISTS playlists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    visibility TEXT DEFAULT 'private',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS playlist_videos (
    playlist_id INTEGER NOT NULL,
    video_id INTEGER NOT NULL,
    position INTEGER,
    PRIMARY KEY (playlist_id, video_id),
    FOREIGN KEY (playlist_id) REFERENCES playlists(id),
    FOREIGN KEY (video_id) REFERENCES videos(id)
  );
`);

const videoStorage = multer.diskStorage({
  destination: (req, file, cb) => { const d = path.join(__dirname, "uploads/videos"); fs.mkdirSync(d, { recursive: true }); cb(null, d); },
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});
const thumbnailStorage = multer.diskStorage({
  destination: (req, file, cb) => { const d = path.join(__dirname, "uploads/thumbnails"); fs.mkdirSync(d, { recursive: true }); cb(null, d); },
  filename: (req, file, cb) => cb(null, `thumb-${Date.now()}-${file.originalname}`),
});
const uploadVideo = multer({ storage: videoStorage, limits: { fileSize: 2 * 1024 * 1024 * 1024 } });
const uploadThumb = multer({ storage: thumbnailStorage, limits: { fileSize: 5 * 1024 * 1024 } });

const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "No token" });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); } catch { res.status(401).json({ error: "Invalid token" }); }
};
const optionalAuth = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (token) { try { req.user = jwt.verify(token, JWT_SECRET); } catch {} }
  next();
};

// AUTH
app.post("/api/auth/register", async (req, res) => {
  const { username, email, password, channelName } = req.body;
  if (!username || !email || !password) return res.status(400).json({ error: "All fields required" });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users (username, email, password_hash, channel_name) VALUES (?, ?, ?, ?)").run(username, email, hash, channelName || username);
    const user = db.prepare("SELECT id, username, email, channel_name FROM users WHERE id = ?").get(result.lastInsertRowid);
    const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: "7d" });
    res.json({ user, token });
  } catch (e) {
    if (e.message.includes("UNIQUE")) return res.status(409).json({ error: "Username or email already exists" });
    res.status(500).json({ error: "Registration failed" });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user) return res.status(401).json({ error: "Invalid credentials" });
  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) return res.status(401).json({ error: "Invalid credentials" });
  const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: "7d" });
  const { password_hash, ...safeUser } = user;
  res.json({ user: safeUser, token });
});

app.get("/api/auth/me", authenticate, (req, res) => {
  const user = db.prepare("SELECT id, username, email, channel_name, avatar_url, subscriber_count FROM users WHERE id = ?").get(req.user.id);
  res.json(user);
});

// VIDEOS
app.get("/api/videos", optionalAuth, (req, res) => {
  const { category, search, limit = 20, offset = 0 } = req.query;
  let query = `SELECT v.*, u.username, u.channel_name, u.avatar_url FROM videos v JOIN users u ON v.user_id = u.id WHERE v.visibility = 'public'`;
  const params = [];
  if (category && category !== "All") { query += " AND v.category = ?"; params.push(category); }
  if (search) { query += " AND (v.title LIKE ? OR v.description LIKE ?)"; params.push(`%${search}%`, `%${search}%`); }
  query += " ORDER BY v.created_at DESC LIMIT ? OFFSET ?";
  params.push(Number(limit), Number(offset));
  res.json(db.prepare(query).all(...params));
});

app.get("/api/videos/:id", optionalAuth, (req, res) => {
  const video = db.prepare(`SELECT v.*, u.username, u.channel_name, u.avatar_url, u.subscriber_count FROM videos v JOIN users u ON v.user_id = u.id WHERE v.id = ?`).get(req.params.id);
  if (!video) return res.status(404).json({ error: "Not found" });
  db.prepare("UPDATE videos SET view_count = view_count + 1 WHERE id = ?").run(req.params.id);
  if (req.user) {
    video.userLike = db.prepare("SELECT type FROM likes WHERE user_id = ? AND video_id = ?").get(req.user.id, video.id);
    video.userSubscribed = !!db.prepare("SELECT id FROM subscriptions WHERE subscriber_id = ? AND channel_id = ?").get(req.user.id, video.user_id);
    db.prepare("INSERT OR REPLACE INTO watch_history (user_id, video_id) VALUES (?, ?)").run(req.user.id, video.id);
  }
  res.json(video);
});

app.post("/api/videos", authenticate, uploadVideo.single("video"), (req, res) => {
  const { title, description, tags, category, visibility } = req.body;
  if (!req.file) return res.status(400).json({ error: "No video file" });
  const result = db.prepare("INSERT INTO videos (user_id, title, description, video_url, tags, category, visibility) VALUES (?, ?, ?, ?, ?, ?, ?)").run(req.user.id, title, description, `/uploads/videos/${req.file.filename}`, tags || "[]", category || "General", visibility || "public");
  res.json(db.prepare("SELECT * FROM videos WHERE id = ?").get(result.lastInsertRowid));
});

app.put("/api/videos/:id", authenticate, (req, res) => {
  const video = db.prepare("SELECT * FROM videos WHERE id = ?").get(req.params.id);
  if (!video || video.user_id !== req.user.id) return res.status(403).json({ error: "Forbidden" });
  const { title, description, tags, category, visibility } = req.body;
  db.prepare("UPDATE videos SET title=?, description=?, tags=?, category=?, visibility=? WHERE id=?").run(title||video.title, description||video.description, tags||video.tags, category||video.category, visibility||video.visibility, video.id);
  res.json(db.prepare("SELECT * FROM videos WHERE id = ?").get(video.id));
});

app.delete("/api/videos/:id", authenticate, (req, res) => {
  const video = db.prepare("SELECT * FROM videos WHERE id = ?").get(req.params.id);
  if (!video || video.user_id !== req.user.id) return res.status(403).json({ error: "Forbidden" });
  const fp = path.join(__dirname, video.video_url);
  if (fs.existsSync(fp)) fs.unlinkSync(fp);
  db.prepare("DELETE FROM videos WHERE id = ?").run(video.id);
  res.json({ success: true });
});

app.post("/api/videos/:id/thumbnail", authenticate, uploadThumb.single("thumbnail"), (req, res) => {
  const video = db.prepare("SELECT * FROM videos WHERE id = ?").get(req.params.id);
  if (!video || video.user_id !== req.user.id) return res.status(403).json({ error: "Forbidden" });
  const thumbUrl = `/uploads/thumbnails/${req.file.filename}`;
  db.prepare("UPDATE videos SET thumbnail_url = ? WHERE id = ?").run(thumbUrl, video.id);
  res.json({ thumbnail_url: thumbUrl });
});

// LIKES
app.post("/api/videos/:id/like", authenticate, (req, res) => {
  const { type } = req.body;
  const existing = db.prepare("SELECT * FROM likes WHERE user_id = ? AND video_id = ?").get(req.user.id, req.params.id);
  if (existing) {
    if (existing.type === type) {
      db.prepare("DELETE FROM likes WHERE user_id = ? AND video_id = ?").run(req.user.id, req.params.id);
      db.prepare(`UPDATE videos SET ${type}_count = ${type}_count - 1 WHERE id = ?`).run(req.params.id);
    } else {
      db.prepare("UPDATE likes SET type = ? WHERE user_id = ? AND video_id = ?").run(type, req.user.id, req.params.id);
      db.prepare(`UPDATE videos SET ${type}_count = ${type}_count + 1, ${existing.type}_count = ${existing.type}_count - 1 WHERE id = ?`).run(req.params.id);
    }
  } else {
    db.prepare("INSERT INTO likes (user_id, video_id, type) VALUES (?, ?, ?)").run(req.user.id, req.params.id, type);
    db.prepare(`UPDATE videos SET ${type}_count = ${type}_count + 1 WHERE id = ?`).run(req.params.id);
  }
  res.json(db.prepare("SELECT like_count, dislike_count FROM videos WHERE id = ?").get(req.params.id));
});

// COMMENTS
app.get("/api/videos/:id/comments", (req, res) => {
  const comments = db.prepare(`SELECT c.*, u.username, u.avatar_url FROM comments c JOIN users u ON c.user_id = u.id WHERE c.video_id = ? AND c.parent_id IS NULL ORDER BY c.created_at DESC`).all(req.params.id);
  res.json(comments.map(c => ({ ...c, replies: db.prepare(`SELECT c.*, u.username, u.avatar_url FROM comments c JOIN users u ON c.user_id = u.id WHERE c.parent_id = ? ORDER BY c.created_at ASC`).all(c.id) })));
});

app.post("/api/videos/:id/comments", authenticate, (req, res) => {
  const { text, parentId } = req.body;
  if (!text?.trim()) return res.status(400).json({ error: "Required" });
  const result = db.prepare("INSERT INTO comments (video_id, user_id, parent_id, text) VALUES (?, ?, ?, ?)").run(req.params.id, req.user.id, parentId || null, text.trim());
  db.prepare("UPDATE videos SET comment_count = comment_count + 1 WHERE id = ?").run(req.params.id);
  res.json(db.prepare("SELECT c.*, u.username, u.avatar_url FROM comments c JOIN users u ON c.user_id = u.id WHERE c.id = ?").get(result.lastInsertRowid));
});

app.delete("/api/comments/:id", authenticate, (req, res) => {
  const comment = db.prepare("SELECT * FROM comments WHERE id = ?").get(req.params.id);
  if (!comment || comment.user_id !== req.user.id) return res.status(403).json({ error: "Forbidden" });
  db.prepare("DELETE FROM comments WHERE id = ?").run(req.params.id);
  db.prepare("UPDATE videos SET comment_count = comment_count - 1 WHERE id = ?").run(comment.video_id);
  res.json({ success: true });
});

// SUBSCRIPTIONS
app.post("/api/channels/:channelId/subscribe", authenticate, (req, res) => {
  const existing = db.prepare("SELECT * FROM subscriptions WHERE subscriber_id = ? AND channel_id = ?").get(req.user.id, req.params.channelId);
  if (existing) {
    db.prepare("DELETE FROM subscriptions WHERE subscriber_id = ? AND channel_id = ?").run(req.user.id, req.params.channelId);
    db.prepare("UPDATE users SET subscriber_count = subscriber_count - 1 WHERE id = ?").run(req.params.channelId);
    res.json({ subscribed: false });
  } else {
    db.prepare("INSERT INTO subscriptions (subscriber_id, channel_id) VALUES (?, ?)").run(req.user.id, req.params.channelId);
    db.prepare("UPDATE users SET subscriber_count = subscriber_count + 1 WHERE id = ?").run(req.params.channelId);
    res.json({ subscribed: true });
  }
});

app.get("/api/subscriptions", authenticate, (req, res) => {
  res.json(db.prepare(`SELECT v.*, u.username, u.channel_name, u.avatar_url FROM videos v JOIN users u ON v.user_id = u.id JOIN subscriptions s ON s.channel_id = v.user_id WHERE s.subscriber_id = ? AND v.visibility = 'public' ORDER BY v.created_at DESC LIMIT 40`).all(req.user.id));
});

app.get("/api/channels/:id", optionalAuth, (req, res) => {
  const channel = db.prepare("SELECT id, username, channel_name, avatar_url, subscriber_count, created_at FROM users WHERE id = ?").get(req.params.id);
  if (!channel) return res.status(404).json({ error: "Not found" });
  channel.videos = db.prepare("SELECT * FROM videos WHERE user_id = ? AND visibility = 'public' ORDER BY created_at DESC").all(req.params.id);
  if (req.user) channel.isSubscribed = !!db.prepare("SELECT id FROM subscriptions WHERE subscriber_id = ? AND channel_id = ?").get(req.user.id, req.params.id);
  res.json(channel);
});

// PLAYLISTS
app.post("/api/playlists", authenticate, (req, res) => {
  const { name, description, visibility } = req.body;
  const result = db.prepare("INSERT INTO playlists (user_id, name, description, visibility) VALUES (?, ?, ?, ?)").run(req.user.id, name, description, visibility || "private");
  res.json(db.prepare("SELECT * FROM playlists WHERE id = ?").get(result.lastInsertRowid));
});

app.post("/api/playlists/:id/videos", authenticate, (req, res) => {
  const { videoId } = req.body;
  const playlist = db.prepare("SELECT * FROM playlists WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!playlist) return res.status(403).json({ error: "Forbidden" });
  const count = db.prepare("SELECT COUNT(*) as c FROM playlist_videos WHERE playlist_id = ?").get(req.params.id).c;
  db.prepare("INSERT OR IGNORE INTO playlist_videos (playlist_id, video_id, position) VALUES (?, ?, ?)").run(req.params.id, videoId, count + 1);
  res.json({ success: true });
});

app.get("/api/playlists/:id", (req, res) => {
  const playlist = db.prepare("SELECT * FROM playlists WHERE id = ?").get(req.params.id);
  if (!playlist) return res.status(404).json({ error: "Not found" });
  playlist.videos = db.prepare(`SELECT v.*, u.username, u.channel_name FROM videos v JOIN playlist_videos pv ON pv.video_id = v.id JOIN users u ON v.user_id = u.id WHERE pv.playlist_id = ? ORDER BY pv.position`).all(req.params.id);
  res.json(playlist);
});

app.listen(PORT, () => console.log(`🎬 YouTube Clone API → http://localhost:${PORT}`));
module.exports = app;
