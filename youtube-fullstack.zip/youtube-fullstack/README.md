# 🎬 YouTube Clone — Full-Stack Setup Guide

A feature-complete YouTube clone with video upload, comments, subscriptions, likes, playlists, search, watch history, and channel pages.

---

## 🏗️ Tech Stack

| Layer | Technology |
|---|---|
| **Frontend** | React 18, React Router, Axios |
| **Backend** | Node.js, Express.js |
| **Database** | SQLite (dev) → swap to PostgreSQL for production |
| **Auth** | JWT (JSON Web Tokens) + bcrypt |
| **File Storage** | Local Multer (dev) → swap to AWS S3/Cloudflare R2 for production |
| **Video Player** | HTML5 `<video>` tag |

---

## 📁 Project Structure

```
youtube-fullstack/
├── server/
│   ├── index.js          ← Express API (all routes)
│   ├── package.json
│   └── uploads/          ← auto-created, stores video files
│       ├── videos/
│       └── thumbnails/
│
└── client/
    ├── src/
    │   ├── api.js                   ← Axios client + API helpers
    │   ├── context/
    │   │   └── AuthContext.js       ← Login/register/logout state
    │   ├── components/
    │   │   ├── UploadModal.jsx      ← Full upload flow with progress
    │   │   ├── VideoCard.jsx        ← Thumbnail card component
    │   │   ├── VideoPlayer.jsx      ← HTML5 player + controls
    │   │   ├── CommentSection.jsx   ← Threaded comments
    │   │   ├── Sidebar.jsx          ← Navigation + subscriptions
    │   │   └── Navbar.jsx           ← Search + upload + user menu
    │   ├── pages/
    │   │   ├── Home.jsx             ← Video grid with category filter
    │   │   ├── Watch.jsx            ← Video player page
    │   │   ├── Channel.jsx          ← Channel page
    │   │   ├── Subscriptions.jsx    ← Subscription feed
    │   │   ├── Library.jsx          ← Playlists + liked videos
    │   │   ├── History.jsx          ← Watch history
    │   │   └── Search.jsx           ← Search results
    │   └── App.jsx
    └── package.json
```

---

## 🚀 Quick Start

### 1. Install & run the backend
```bash
cd server
npm install
npm run dev
# ✅ API running at http://localhost:5000
```

### 2. Install & run the frontend
```bash
cd client
npx create-react-app . --template cra-template
# OR: npm create vite@latest . -- --template react
npm install axios react-router-dom
npm start
# ✅ App running at http://localhost:3000
```

---

## 📡 API Reference

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Login → returns JWT |
| GET | `/api/auth/me` | Get current user (auth required) |

### Videos
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/videos` | List videos (supports `?search=`, `?category=`) |
| GET | `/api/videos/:id` | Get single video + increment view count |
| POST | `/api/videos` | Upload video (multipart/form-data, auth required) |
| PUT | `/api/videos/:id` | Edit video (auth required, owner only) |
| DELETE | `/api/videos/:id` | Delete video (auth required, owner only) |
| POST | `/api/videos/:id/thumbnail` | Upload thumbnail (auth required) |
| POST | `/api/videos/:id/like` | Like or dislike (auth required, body: `{type: "like"|"dislike"}`) |

### Comments
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/videos/:id/comments` | Get threaded comments |
| POST | `/api/videos/:id/comments` | Post comment (auth required, body: `{text, parentId?}`) |
| DELETE | `/api/comments/:id` | Delete comment (auth required, owner only) |

### Channels & Subscriptions
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/channels/:id` | Get channel info + videos |
| POST | `/api/channels/:id/subscribe` | Toggle subscribe (auth required) |
| GET | `/api/subscriptions` | Get subscription feed (auth required) |

### Playlists
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/playlists` | Create playlist (auth required) |
| GET | `/api/playlists/:id` | Get playlist + videos |
| POST | `/api/playlists/:id/videos` | Add video to playlist (auth required) |

---

## 🔧 Environment Variables

### server/.env
```
PORT=5000
JWT_SECRET=your-very-long-random-secret-key-here
```

### client/.env
```
REACT_APP_API_URL=http://localhost:5000/api
```

---

## 🌐 Production Deployment

### Backend → Railway / Render / Fly.io
1. Replace SQLite with PostgreSQL: `npm install pg knex`
2. Replace Multer local storage with AWS S3 or Cloudflare R2
3. Add HTTPS and update CORS origins
4. Set `JWT_SECRET` to a secure 64-character random string

### Frontend → Vercel / Netlify
```bash
npm run build
# Deploy the /build folder
```

---

## ✨ Features Checklist

- [x] User registration & login (JWT auth)
- [x] Video upload with drag & drop + progress bar
- [x] Custom thumbnail upload
- [x] Video player (HTML5)
- [x] Like / Dislike videos
- [x] Threaded comments with replies
- [x] Subscribe / unsubscribe to channels
- [x] Subscription feed
- [x] Watch history
- [x] Playlists (create, add videos)
- [x] Search by title/description
- [x] Filter by category
- [x] Channel pages
- [x] Video visibility (public / unlisted / private)
- [ ] Live streaming (requires WebRTC + RTMP)
- [ ] Video transcoding (requires FFmpeg pipeline)
- [ ] Push notifications (requires WebSockets)
- [ ] Ad monetization (requires payment processor)

---

## 🔒 Security Notes

- All passwords are hashed with bcrypt (cost factor 12)
- JWTs expire after 7 days
- File uploads are validated by MIME type
- SQL injection is prevented via parameterized queries (better-sqlite3)
- In production: add rate limiting with `express-rate-limit`
- In production: add helmet.js for HTTP security headers

---

Built with ❤️ — a learning project inspired by YouTube.
